<?php

namespace App\Http\Controllers\Api;

use App\Debitos;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Students;

class StudentsController extends Controller
{
    public function add(Request $request){
        try{
            $debt = new Debitos();
            $debt->name = $request->name;
            $debt->cpf_cnpj = $request->cpf_cnpj;
            $debt->valor = $request->valor;
            $debt->email = $request->email;
            $debt->save();

            return ['retorno'=>'ok'];

        } catch(\Exception $erro){
            return ['retorno' =>'erro', 'detalhe'=>$erro];
        }
    }

    public function list(){
        $debt = Debitos::all('id', 'name', 'cpf_cnpj', 'valor', 'email');

        return $debt;
    }

    public function select($id){
        $debt = Debitos::find($id);

        return $debt;
    }

    public function update(Request $request, $id){
        try{

            $debt = Debitos::find($id);

            $debt->name = $request->name;
            $debt->cpf_cnpj = $request->cpf_cnpj;
            $debt->valor = $request->valor;
            $debt->email = $request->email;
            $debt->save();

            return ['retorno'=>'ok'];

        }catch(\Exception $erro){
            return ['retorno' => 'erro', 'detalhes'=>$erro];
        }

    }

    public function delete($id){
        try{

            $debt = Debitos::find($id);

            $debt->delete();

            return ['retorno'=>'ok'];
            
        }catch(\Exception $erro){
            return ['retorno' => 'erro', 'detalhes'=>$erro];
        }

    }

}







