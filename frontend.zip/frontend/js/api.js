const url = 'http://localhost/projeto/public/api/debt';

function buttonCreate() {
    window.location.href = 'create.html';
}


//lista todos os debitos---------------------------------------------------------------//
function showAll() {
    fetch(url, {
            method: 'get',
            headers: new Headers({
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }),
        })
        //recebe a resposta do fetch e verifica o Status da mensagem
        //----------------------------------------------------------//
        .then(function(response) {
            console.log(response); //Exibe no console do browser o conteúdo do response.

            //Se houve resposta de sucesso         
            if (response.status >= 200 && response.status < 300) {
                return response.json();
            }
            //Se a url não foi encontrada
            else if (response.status == 404) {
                alert("url não encontrada");
            } else {
                //Gera uma exceção
                throw new Error(response.statusText);
            }
        })
        //Recebe o json--------------------------------------------------//
        .then(data => {
            console.log(data); //Exibe o JSON no console

            //map - "mapeia" o json através da variável debito
            const html = data.map(Debt => {
                    return `<tr><th id=${Debt.id}>${Debt.id}</th> 
                         <th>${Debt.nameS}</th>
                         <th>${Debt.cpf_cnpj}</th>
                         <th>${Debt.valor}</th>
                         <th>${Debt.email}</th>
                         <th><a href="edit.html?id=${Debt.id}">Editar</a></th>
                         <th><a href="#void" onclick="deleteStudent(${Debt.id});">Deletar</a></th>
                         </tr>`;
                })
                .join(""); //join remove as vírgulas que existiam no JSON
            console.log(html);
            document.querySelector("#list").insertAdjacentHTML("beforeend", html);
        })
        //Execções não tratadas
        .catch(function(error) {
            console.log('Erro - ', error);
        })
}


//Deleta Debito------------------------------------------------------//
function deleteDebt(numero) {
    fetch(url + '/' + numero, {
            method: 'delete'
        })
        //recebe a resposta do fetch e verifica o Status da mensagem
        //----------------------------------------------------------//
        .then((response) => {
            if (response.ok) {
                alert("Registro excluído com sucesso!");
                window.location.href = "index.html";
            }
        })
        //tratamento de exceções
        .catch(function(erro) {
            alert("Erro ao excluir: " + erro);
        })
}


//------------- Create Debitos---------------------------------------//
function createDebt() {
    //Faz a leitura dos inputs
    let nome = document.getElementById("nameS").value;
    let cpf_cnpj = document.getElementById("cpf_cnpj").value;
    let valor = document.getElementById("valor").value;
    let email = document.getElementById("email").value;

    //Cria o Json
    var object = {
        "nameS": nameS,
        "cpf_cnpj": cpf_cnpj,
        "name": valor,
        "email": email
    }

    fetch(url, {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }),
            body: JSON.stringify(object) //Adiciona o Json no Body
        })
        //recebe a resposta do fetch e verifica se foi efetivado
        .then((response) => {
            if (response.ok) {
                alert("Registro criado com sucesso!");
                window.location.href = "index.html";
            }
        })
        //Tratamento de Erro
        .catch(function(erro) {
            alert("Erro ao criar o registro: " + erro);
        })
}


//Busca um debito pelo código--------------------------------------------/
function searchDebt() {
    //Pega o parametro id 
    var urlEdit = new URL(window.location.href);
    var c = urlEdit.searchParams.get("id");

    fetch(url + '/' + c, {
            method: 'get',
            headers: new Headers({
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }),
        })
        //Verifica o retorno do servidor
        .then(response => {
            if (!response.ok) {
                throw Error("Erro");
            }
            return response.json();
        })
        //Preeche os dados do debito nos inputs
        .then(data => {
            console.log(data);
            document.getElementById("idDebt").value = data.id;
            document.getElementById("nameS").value = data.name;
            document.getElementById("cpf_cnpj").value = data.cpf_cnpj;
            document.getElementById("valor").value = data.valor;
            document.getElementById("email").value = data.email;
        })
        //trata exceções
        .catch(function(erro) {
            alert("Erro: " + erro);
        });
}


//Altera Debito-----------------------------------------------------//  
function editDebt() {
    //Faz a leitura dos inputs--------------------------//   
    let id = document.getElementById("idDebt").value;
    let nome = document.getElementById("nameS").value;
    let cpf_cnpj = document.getElementById("cpf_cnpj").value;
    let valor = document.getElementById("valor").value;
    let email = document.getElementById("email").value;

    //JSON com as alteraçoes
    var object = {
        "nameS": nameS,
        "cpf_cnpj": cpf_cnpj,
        "valor": valor,
        "email": email
    }

    fetch(url + '/' + id, {
            method: 'put',
            headers: new Headers({
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }),
            body: JSON.stringify(object)
        })
        //Recebe a resposta da requisição e verifica o seu Status
        .then((response) => {
            //Verifica o Status
            if (response.status == 200 && response.status < 300) {
                alert("Registro alterado com sucesso");
                window.location.href = "index.html"; //redireciona para tela inicial
            } else if (response.status == 422) {
                alert('Alguns campos não foram preenchidos corretamente!')
            }
        })
        .catch(function(erro) {
            alert('Erro: ' + erro);
        })
}